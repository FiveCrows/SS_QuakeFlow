import re
import matplotlib.pyplot as plt
import numpy as np
import statistics as stats
from datetime import datetime
from scipy.spatial.transform import Rotation as R
import obspy
from obspy.core.inventory import Inventory, Network, Station, Channel, Site 
from obspy.clients.nrl import NRL

###to read lines with time in solo logs
def readTime(line):
    line = re.findall('"([^"]*)"', line)[0]
    return datetime.strptime(line, "%Y/%m/%d,%H:%M:%S")
### read lines with floats in solo logs
def readFloat(line):
    return (re.findall("[-+]?(?:\d*\.*\d+)",line))
#######load file
infile = "station1Data/DigiSolo.LOG"
with open(infile) as f:
    f = f.readlines()


#to plot precision data if needed
def predictPrecision(n_days =35):
    nd_precKey = '{}day_mPrecision'.format(n_days)
    nd_precKey_d = '{}day_degPrecision'.format(n_days)
    d_meas = (max(times[start:])-min(times[start:])).total_seconds()/86400
    for key in pos_floats:
        datStats[key][nd_precKey] = datStats[key]['m_err']*np.sqrt(d_meas/n_days) #35 day error
    for key in angle_floats:
        datStats[key][nd_precKey_d] = datStats[key]['mean_err']*np.sqrt(d_meas/n_days) #35 day error    
    ####params for both plots
    fig,ax = plt.subplots(2)
    barWidth = 0.3
    #####plot position precision
    br1 = np.arange(len(pos_floats))
    heights0 = [datStats[key]['std']/5 for key in pos_floats]
    heights1 = [datStats[key]['m_err'] for key in pos_floats]
    heights2 = [datStats[key][nd_precKey] for key in pos_floats]
    ax[0].bar(br1, heights0, color ='r', width = barWidth, edgecolor ='grey', label ='standard deviation/5')
    ax[0].bar(br1+barWidth, heights1, color ='b', width = barWidth, edgecolor ='grey', label ='dataset precision')
    ax[0].bar(br1+2*barWidth, heights2, color ='g', width = barWidth, edgecolor ='grey', label =("{} day precision").format(n_days))
    ax[0].set_ylabel("meters")
    ax[0].set_xticks(br1 + barWidth, pos_floats)
    ###########for degrees
    br1 = np.arange(len(angle_floats))
    heights0 = [datStats[key]['std']/5 for key in angle_floats]
    heights1 = [datStats[key]['mean_err'] for key in angle_floats]
    heights2 = [datStats[key][nd_precKey_d] for key in angle_floats]
    ax[1].bar(br1, heights0, color ='r', width = barWidth, edgecolor ='grey', label ='standard deviation/5')
    ax[1].bar(br1+barWidth, heights1, color ='b', width = barWidth, edgecolor ='grey', label ='dataset precision')
    ax[1].bar(br1+2*barWidth, heights2, color ='g', width = barWidth, edgecolor ='grey', label =("{} day precision").format(n_days))
    ax[1].set_ylabel("degrees")
    ax[1].set_xticks(br1 + barWidth, angle_floats)
    ax[1].bar
    plt.legend()
    plt.show()
#### to plot axes rotation if needed
def plot_rotated_axes(ax, r, name=None, offset=(0, 0, 0), scale=1):
    colors = ("#FF6666", "#005533", "#1199EE")  # Colorblind-safe RGB
    loc = np.array([offset, offset])
    for i, (axis, c) in enumerate(zip((ax.xaxis, ax.yaxis, ax.zaxis),colors)):                                      
        axlabel = axis.axis_name
        axis.set_label_text(axlabel)
        axis.label.set_color(c)
        axis.line.set_color(c)
        axis.set_tick_params(colors=c)
        line = np.zeros((2, 3))
        line[1, i] = scale
        line_rot = r.apply(line)
        line_plot = line_rot + loc
        ax.plot(line_plot[:, 0], line_plot[:, 1], line_plot[:, 2], c)
        text_loc = line[1]*1.2
        text_loc_rot = r.apply(text_loc)
        text_plot = text_loc_rot + loc[0]
        ax.text(*text_plot, axlabel.upper(), color=c,
                va="center", ha="center")
        ax.text(*offset, name, color="k", va="center", ha="center",
            bbox={"fc": "w", "alpha": 0.8, "boxstyle": "circle"})
        


#read serial number, sample rate, and start date
hasSer = False
hasStart = False
hasSR = False
hasDB = False
while (not( hasStart and hasSer and hasSR)):
    line = f.pop(0)
    split = line.split(" = ")
    if len(split) == 2:
        key, value = split[0], split[1]
    else: continue
    if "Serial Number" in key:
        hasSer = True
        ser = int(value)
        print("Serial Number: ", int(value))
    if "Start Date" in key:
        hasStart = True
        startDate = value[value.find("(")+1:value.find(")")][1:-1]
        print("start date"+startDate)                
    if "Sample Rate" in key:
        hasSR = True
        sampleRate = int(value)
        print("Sample Rate: ", sampleRate)
    if "Channel 1 Gain" in key:
            print("Note: assumes all channels have same gain")
            gain = int(value)
            hasDB = True            
            print("dB: ", dB)

#find gps sync blocks
gpsSyncs = [i for i in range(len(f)) if f[i] == "GPS Status = GPS Synchronization\n"]  #locate gps sync record areas
####compile data for all syncs
angle_floats = ["eCompass North", "Tilted Angle", "Roll Angle", "Pitch Angle"]
pos_floats = ["Longitude", "Latitude", "Altitude"]
GPS_floats = angle_floats+pos_floats + ["Satellite Number"]
data = {key:[] for key in GPS_floats}
times = []
for row in gpsSyncs:
    i = 1
    key, value ="UTC Time", readTime(f[row+i])
    times.append(value)
    while f[row+i+1] != "\n":
        i+=1
        key, value = f[row+i].split(" = ")
        key, value = key.strip(), value.strip()
        if key in GPS_floats:
            if value =="Unknown":
                data[key].append(np.NaN)
            else:
                data[key].append(float(value))

######check if there is a time gap
diff = np.diff(times)
mode = stats.mode(diff)
dtMax = np.argmax(diff)
has_timeGap = diff[dtMax]>mode*3
if has_timeGap:
    print("Time gap of {} from".format(diff[dtMax]) + startDate + " detected in {}".format(ser))
    print()
    start = dtMax+1
else:
    start = 0

#check for outliers in data too? 
def plotData():
####plot data    
    ###prime factor len(data)
    fig, ax = plt.subplots(4,2, figsize=(10,10))
    for i in range(4):
        for j in range(2):
            ax[i,j].plot(times[start:], data[GPS_floats[2*i+j]][start:])
            ax[i,j].set_title(GPS_floats[2*i+j])
            ax[i,j].set_xlabel("Time")
            ax[i,j].set_ylabel(GPS_floats[2*i+j])
    fig.suptitle(startDate + " GPS Data for Station {}".format(ser))
    plt.tight_layout()    
    plt.savefig(startDate.replace('/','_')+"_{}_logPlot.png".format(ser))    

#remove outliers
for key in GPS_floats:
    vals = data[key]
    q1 = np.nanpercentile(data[key], 25)
    q3 = np.nanpercentile(data[key], 75)
    IQR = q3-q1
    lwr_bound = q1-(3*IQR)
    upr_bound = q3+(3*IQR)
    for i in range(len(vals)):            
        if vals[i] < lwr_bound or vals[i] > upr_bound:
            vals[i] = np.nan

#calculate average means and std for each parameter
#avg_vals = {key:np.mean([x for x in data[key] if x!=None]) for key in GPS_floats}
stdevs = {key:np.nanstd(data[key]) for key in GPS_floats}
datStats = {key:{'mean': np.nanmean(data[key]),
                  'std': stdevs[key],
                  'mean_err': stdevs[key]/np.sqrt(len(np.array(data[key])[~np.isnan(data[key])]))
                  }
            for key in GPS_floats}
                  
#convert to meters
for key in ["Latitude","Longitude"]:
    datStats[key]['m_err'] = datStats[key]['mean_err']*111139
datStats['Altitude']['m_err'] = datStats['Altitude']['mean_err']



r1 = R.from_euler('XYZ', [datStats["Roll Angle"]["mean"], datStats["Pitch Angle"]["mean"], datStats["eCompass North"]["mean"]], degrees=True)
xyz = {'X':[1,0,0],'Y':[0,1,0],'Z':[0,0,1]}
dips = {key:-90+np.arccos(np.dot(r1.apply(xyz[key]),[0,0,1]))*180/np.pi for key in xyz}
azimuths = {key:np.arctan2(r1.apply(xyz[key])[0],r1.apply(xyz[key])[1])*180/np.pi for key in xyz}
#####get dips and azimuths of basis vectors under rotation r1



###### construct station  
lat= datStats["Latitude"]["mean"]
long = datStats["Longitude"]["mean"]
alt = datStats["Altitude"]["mean"]
sta = Station(
    code = ser,
    longitude = long,
    latitude = lat,
    elevation = alt,
    creation_date =startDate,
    site = Site(name = "paradox")
)

cha_x = Channel(
    code = "LHX",
    location_code = "",
    latitude = lat,
    longitude = long,
    elevation = alt,
    #azimuth = 90,
    dip =         dips['X'],
    azimuth = azimuths['X'],
    sample_rate = sampleRate,
    depth = 0)

cha_y = Channel(
    code = "LHY",
    location_code = "",
    longitude = long,
    latitude = lat,
    dip =         dips['Y'],
    azimuth = azimuths['Y'],
    elevation = alt,
    sample_rate = sampleRate,
    depth = 0)

cha_z = Channel(
    code = "LHZ",
    location_code = "",
    latitude = lat,
    longitude = long,
    elevation = alt,
    dip =         dips['Z'],
    azimuth = azimuths['Z'],
    sample_rate = sampleRate,
    depth = 0)

manufacturer = 'DTCC (manufacturers of SmartSolo'
device = 'SmartSolo IGU-16HR3C'
preampGain = list(filter(lambda key: ("{} dB".format(gain) in key),NRL().dataloggers[manufacturer][device]))## match preamp gain from NRL
filterType = 'Linear Phase'
IIR_Low_Cut = 'Off'
low_freq = '5 Hz'

sensorKeys = ['DTCC (manuafacturers of SmartSolo)','5 Hz','Rc=1850, Rs=430000']
dataloggerKeys = [manufacturer, device, preampGain, sampleRate, filterType, IIR_Low_Cut]
nrl = NRL()
response = nrl.get_response( # doctest: +SKIP
    sensor_keys=['Streckeisen', 'STS-1', '360 seconds'],
    datalogger_keys=['REF TEK', 'RT 130 & 130-SMA', '1', '200'])
response.plot(min_freq=1E-4, output='DISP')
